package com.xantrix.webapp.exceptions;

import java.util.Date;

public class ErrorResponse {

	private Date data = new Date();
	private int code;
	private String message;
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	

	
}
