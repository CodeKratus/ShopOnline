package com.xantrix.webapp.dtos;





public class BarcodeDto {
	private String barcode;
	private String idTipoArt;
	
	
	public String getBarcode() {
		return barcode;
	}
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	public String getIdTipoArt() {
		return idTipoArt;
	}
	public void setIdTipoArt(String idTipoArt) {
		this.idTipoArt = idTipoArt;
	}



}
