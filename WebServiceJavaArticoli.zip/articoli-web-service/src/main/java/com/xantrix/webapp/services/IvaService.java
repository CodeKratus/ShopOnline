package com.xantrix.webapp.services;

import java.util.List;

import com.xantrix.webapp.dtos.IvaDto;

public interface IvaService 
{
	public List<IvaDto> SelTutti();
}
