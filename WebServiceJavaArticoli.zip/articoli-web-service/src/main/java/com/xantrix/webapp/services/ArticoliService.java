package com.xantrix.webapp.services;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.xantrix.webapp.dtos.ArticoliDto;
import com.xantrix.webapp.entities.Articoli;
//il service in mvc viene omesso ma quando abbiamo tante classi puo esserci utile per dividere la logica di buisness
//da quella di persistenza che verrà gestita nel controller
public interface ArticoliService {

	
	public Iterable<Articoli> SelTutti();
    public List<ArticoliDto> SelByDescrizione(String descrizione);
    public List<ArticoliDto> SelByDescrizione(String descrizione,Pageable pageable);
    public ArticoliDto SelByCodArt(String codArt);
    public ArticoliDto SelByBarcode(String barcode);
    public void DelArticolo(Articoli articolo);
    public void InsArticolo(Articoli articolo);
	
	
 

}
