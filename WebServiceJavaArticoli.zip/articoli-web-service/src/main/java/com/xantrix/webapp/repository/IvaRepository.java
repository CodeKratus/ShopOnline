package com.xantrix.webapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

 
import com.xantrix.webapp.entities.Iva;

public interface IvaRepository  extends JpaRepository<Iva, Integer>
{

}
