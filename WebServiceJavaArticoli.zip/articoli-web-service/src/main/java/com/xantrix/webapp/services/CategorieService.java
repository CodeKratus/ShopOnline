package com.xantrix.webapp.services;

import java.util.List;

import com.xantrix.webapp.dtos.CategoriaDto;

public interface CategorieService 
{
	public List<CategoriaDto> SelTutti();
}
