package com.xantrix.webapp.dtos;


public class IvaDto {
	private int idIva;
	
	
	private String descrizione;
	

	private int aliquota;


	public int getIdIva() {
		return idIva;
	}


	public void setIdIva(int idIva) {
		this.idIva = idIva;
	}


	public String getDescrizione() {
		return descrizione;
	}


	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}


	public int getAliquota() {
		return aliquota;
	}


	public void setAliquota(int aliquota) {
		this.aliquota = aliquota;
	}
	

}
