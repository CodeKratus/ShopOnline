package com.xantrix.webapp.dtos;

import java.time.LocalDate;

public class InfoMsg {

	public LocalDate data;
	public String message;
	public InfoMsg(LocalDate data, String message) {
		super();
		this.data = data;
		this.message = message;
	}
	public LocalDate getData() {
		return data;
	}
	public void setData(LocalDate data) {
		this.data = data;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}
