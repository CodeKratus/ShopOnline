package com.xantrix.webapp.dtos;



public class IngredientiDto {

	
private String codArt;
	

	private String info;


	public String getCodArt() {
		return codArt;
	}


	public void setCodArt(String codArt) {
		this.codArt = codArt;
	}


	public String getInfo() {
		return info;
	}


	public void setInfo(String info) {
		this.info = info;
	}
	
	

}
