package com.xantrix.webapp.controllers;

import java.time.LocalDate;
import java.util.List;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.xantrix.webapp.dtos.ArticoliDto;
import com.xantrix.webapp.dtos.InfoMsg;
import com.xantrix.webapp.entities.Articoli;
import com.xantrix.webapp.exceptions.BindingException;
import com.xantrix.webapp.exceptions.DuplicateException;
import com.xantrix.webapp.exceptions.NotFoundException;
import com.xantrix.webapp.services.ArticoliService;




@RestController
@RequestMapping("api/articoli")
@CrossOrigin("http://localhost:4200")
public class ArticoliController 
{
	private static final Logger logger = LoggerFactory.getLogger(ArticoliController.class);
	

	@Autowired
	private ArticoliService articoliService;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	private ResourceBundleMessageSource errMessage;
	
	@GetMapping(value = "/cerca/barcode/{ean}", produces = "application/json")
	public ResponseEntity<ArticoliDto> listArtByEan(@PathVariable("ean") String Ean)
	throws NotFoundException
	{
		logger.info("****** Otteniamo l'articolo con barcode " + Ean + " *******");
		
		ArticoliDto articolo = articoliService.SelByBarcode(Ean);
		
		if (articolo == null)
		{
			String ErrMsg = String.format("Il barcode %s non è stato trovato!", Ean);
			
			logger.warn(ErrMsg);
			 
			
			throw new NotFoundException(ErrMsg);
			//return new ResponseEntity<Articoli>(HttpStatus.NOT_FOUND);
		}
		
		
		return new ResponseEntity<ArticoliDto>(articolo, HttpStatus.OK);
		
	}
	
	@GetMapping(value="/cerca/codice/{codart}", produces = "application/json")
	public ResponseEntity<ArticoliDto> listArtByCodArt(@PathVariable("codart") String CodArt)
	throws NotFoundException{
		logger.info("****** Otteniamo l'articolo con codice " + CodArt + " *******");
		ArticoliDto articolo = articoliService.SelByCodArt(CodArt);
		
		if(articolo == null) {
			String ErrMsg = String.format("L'articolo con codice %s non è stato trovato!", CodArt);
			logger.warn(ErrMsg);
			throw new NotFoundException(ErrMsg);
		}
		
		return new ResponseEntity<ArticoliDto>(articolo,HttpStatus.OK);
	}
	
	@GetMapping(value="/cerca/descrizione/{filter}",produces = "application/json")
	public ResponseEntity<List<ArticoliDto>> listArtByDesc(@PathVariable("filter")String Filter)
	throws NotFoundException{
		logger.info("********* Otteniamo gli articoli con Descrizione " + Filter + " **********");
		
		List<ArticoliDto> articoli = articoliService.SelByDescrizione(Filter.toUpperCase() + "%");
		
		
		if(articoli.isEmpty()) {
			String ErrMsg = String.format("Non è stato trovato alcun articolo avente descrizione %s", Filter);
			logger.warn(ErrMsg);
			throw new NotFoundException(ErrMsg);
		}
		return new ResponseEntity<List<ArticoliDto>>(articoli,HttpStatus.OK);
	}
	
	@PostMapping(value = "/inserisci")
	public ResponseEntity<InfoMsg> createArt (@Valid @RequestBody Articoli articolo,BindingResult bindingResult)
	throws BindingException,DuplicateException{
		logger.info("Salviamo l 'articolo con codice " + articolo.getCodArt());
		if(bindingResult.hasErrors())
		{
			String MsgErr = errMessage.getMessage(bindingResult.getFieldError(), LocaleContextHolder.getLocale());
			logger.warn(MsgErr);
			throw new BindingException(MsgErr);
			
		}
		
		ArticoliDto checkArt = articoliService.SelByCodArt(articolo.getCodArt());
		if(checkArt != null)
		{
			String MsgErr = String.format("Articolo %s presente in anagrafica! " + "Impossibile utilizzare il metodo POST", articolo.getCodArt());
			logger.warn(MsgErr);
			throw new DuplicateException(MsgErr);
		}
		
		articoliService.InsArticolo(articolo);
		return new ResponseEntity<InfoMsg>(new InfoMsg(LocalDate.now(),"Inserimento Articolo Eseguita con successo!"), HttpStatus.CREATED);
		
	}
	
	
	@RequestMapping(value ="/modifica" , method = RequestMethod.PUT)
	public ResponseEntity<InfoMsg> updateArt (@Valid @RequestBody Articoli articolo,BindingResult bindingResult)
	throws BindingException,NotFoundException
	{
		logger.info("Modifichiamo l'articolo con codice " + articolo.getCodArt());
		if(bindingResult.hasErrors())
		{
			String MsgErr = errMessage.getMessage(bindingResult.getFieldError(),LocaleContextHolder.getLocale());
			logger.warn(MsgErr);
			throw new BindingException(MsgErr);
		}
		ArticoliDto checkArt = articoliService.SelByCodArt(articolo.getCodArt());
		if(checkArt == null)
		{
			String MsgErr = String.format("Articolo %s non presente in anagrafica! " + "Impossibile utilizzare il metodo PUT", articolo.getCodArt());
		logger.warn(MsgErr);
		throw new NotFoundException(MsgErr);
		}
		
		articoliService.InsArticolo(articolo);
		return new ResponseEntity<InfoMsg>(new InfoMsg(LocalDate.now(),"Modifica Articolo Eseguita con successo!"), HttpStatus.CREATED);
		
	}
	
	
	@RequestMapping(value ="/elimina/{codart}" , method = RequestMethod.DELETE,produces = "application/json")
	public ResponseEntity<?> deleteArt (@PathVariable("codart") String CodArt) 
	throws NotFoundException,DuplicateException
	{
		Articoli art ;
		logger.info("Eliminiamo l'articolo con codice" + CodArt);
		
		if(CodArt.equals("123Test")) {
			String MsgErr = String.format("Articolo %s NON ELIMINABILE!", CodArt);
			logger.warn(MsgErr);
			throw new DuplicateException(MsgErr);
		}
		ArticoliDto articolo = articoliService.SelByCodArt(CodArt);
		if(articolo == null)
		{
			String MsgErr = String.format("Articolo %s non presente in anagrafica! ", CodArt);
			logger.warn(MsgErr);
			throw new NotFoundException(MsgErr);
		}
		art = modelMapper.map(articolo, Articoli.class);
		articoliService.DelArticolo(art);
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode responseNode = mapper.createObjectNode();
		
		responseNode.put("code", HttpStatus.OK.toString());
		responseNode.put("message", "Eliminazione Articolo " + CodArt + " Eseguita Con Successo");
       return new ResponseEntity<>(responseNode, new HttpHeaders(), HttpStatus.OK);		
	}
	
}
