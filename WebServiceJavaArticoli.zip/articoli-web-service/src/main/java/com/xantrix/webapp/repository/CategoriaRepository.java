package com.xantrix.webapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xantrix.webapp.entities.FamAssort;

public interface CategoriaRepository extends JpaRepository<FamAssort, Integer>
{

}
