package com.xantrix.webapp.services;

import org.springframework.transaction.annotation.Transactional;


import com.xantrix.webapp.dtos.ArticoliDto;
import com.xantrix.webapp.entities.Articoli;
import com.xantrix.webapp.repository.ArticoliRepository;


import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@Transactional(readOnly = true)
public class ArticoliServiceImpl implements ArticoliService
{
	@Autowired
	ArticoliRepository articoliRepository;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Override
	public Iterable<Articoli> SelTutti()
	{
		return articoliRepository.findAll();
	}
	
	
	private ArticoliDto ConvertToDto(Articoli articoli) {
		ArticoliDto articoliDto = null;
		
		if( articoli != null) {
			articoliDto = modelMapper.map(articoli, ArticoliDto.class);
			/*
			articoliDto.setUm(articoliDto.getUm().trim());
			articoliDto.setIdStatoArt(articoliDto.getIdStatoArt().trim());
			articoliDto.setDescrizione(articoliDto.getDescrizione().trim());*/
		}
		return articoliDto;
	}
	
	
	@Override
	public ArticoliDto SelByBarcode(String barcode) {
		
	Articoli articoli = articoliRepository.SelByEan(barcode);
	
	return this.ConvertToDto(articoli);
	}
	
	@Override
	public ArticoliDto SelByCodArt(String codArt)
	{
		
		Articoli articoli = articoliRepository.findByCodArt(codArt);
		return this.ConvertToDto(articoli);
	}

	@Override
	public List<ArticoliDto> SelByDescrizione(String descrizione, Pageable pageable) {
		
		
		List<Articoli> articoli = articoliRepository.findByDescrizioneLike(descrizione, pageable);
		
		/*articoli.forEach(e -> e.setIdStatoArt(e.getIdStatoArt().trim()));
		articoli.forEach(e-> e.setUm(e.getUm().trim()));
		articoli.forEach(e -> e.setDescrizione(e.getDescrizione().trim()));
		*/
		List<ArticoliDto> retVal = articoli
				.stream()
				.map(source -> modelMapper.map(source, ArticoliDto.class))
				.collect(Collectors.toList());
		return retVal;
	
		
	}


	@Override
	public List<ArticoliDto> SelByDescrizione(String descrizione)
	{
		String filter = "%" + descrizione.toUpperCase() + "%";
		List<Articoli> articoli = articoliRepository.SelByDescrizioneLike(filter);
		/*articoli.forEach(e -> e.setDescrizione(e.getDescrizione().trim()));
		articoli.forEach(e -> e.setIdStatoArt(e.getIdStatoArt().trim()));
		articoli.forEach(e-> e.setUm(e.getUm().trim()));
		*/
		List<ArticoliDto> retVal = articoli
				.stream()
				.map(source -> modelMapper.map(source, ArticoliDto.class))
				.collect(Collectors.toList());
		return retVal;
	}
	


	@Override
	@Transactional
	public void DelArticolo(Articoli articolo)
	{
		articoliRepository.delete(articolo);
	}

	@Override
	@Transactional
	public void InsArticolo(Articoli articolo)
	{
		articolo.setDescrizione(articolo.getDescrizione().toUpperCase());
		articoliRepository.save(articolo);
	}










}

